import React, { useState, useRef, useEffect } from 'react';
import Webcam from 'react-webcam';
import * as faceDetection from '@tensorflow-models/face-detection';
import '@tensorflow/tfjs';
import { Brain, Mic, Camera, MessageSquare, Power } from 'lucide-react';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [messages, setMessages] = useState<Array<{ text: string; sender: 'user' | 'jarvis' }>>([]);
  const webcamRef = useRef<Webcam>(null);
  const [detector, setDetector] = useState<faceDetection.FaceDetector | null>(null);

  const {
    transcript,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  useEffect(() => {
    const loadModel = async () => {
      const model = await faceDetection.createDetector(
        faceDetection.SupportedModels.MediaPipeFaceDetector,
        { runtime: 'tfjs' }
      );
      setDetector(model);
    };
    loadModel();
  }, []);

  const handleAuthentication = async () => {
    if (!detector || !webcamRef.current) return;

    const video = webcamRef.current.video;
    if (!video) return;

    try {
      const faces = await detector.estimateFaces(video);
      if (faces.length === 1) {
        setIsAuthenticated(true);
        speak("Welcome back, sir. How may I assist you today?");
      }
    } catch (error) {
      console.error('Face detection error:', error);
    }
  };

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utterance);
    setMessages(prev => [...prev, { text, sender: 'jarvis' }]);
  };

  const handleVoiceCommand = () => {
    if (!browserSupportsSpeechRecognition) {
      speak("I'm sorry, but your browser doesn't support voice recognition.");
      return;
    }

    if (isListening) {
      SpeechRecognition.stopListening();
      setIsListening(false);
      if (transcript) {
        setMessages(prev => [...prev, { text: transcript, sender: 'user' }]);
        // Simple response logic - can be expanded
        const response = `I heard you say: ${transcript}`;
        speak(response);
      }
      resetTranscript();
    } else {
      setIsListening(true);
      SpeechRecognition.startListening({ continuous: true });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <div className="container mx-auto px-4 py-8">
        {!isAuthenticated ? (
          <div className="flex flex-col items-center justify-center min-h-screen">
            <div className="relative w-96 h-72 bg-black rounded-lg overflow-hidden mb-4">
              <Webcam
                ref={webcamRef}
                className="absolute inset-0 w-full h-full object-cover"
                mirrored={true}
              />
            </div>
            <button
              onClick={handleAuthentication}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-full text-lg font-semibold transition-colors"
            >
              <Camera className="w-6 h-6" />
              Authenticate
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="bg-gray-800 p-6 rounded-xl">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <Brain className="w-6 h-6" />
                    J.A.R.V.I.S
                  </h2>
                  <button
                    onClick={() => setIsAuthenticated(false)}
                    className="text-red-500 hover:text-red-400"
                  >
                    <Power className="w-6 h-6" />
                  </button>
                </div>
                <p className="text-gray-300">
                  Your personal AI assistant is ready to help.
                </p>
              </div>

              <div className="bg-gray-800 p-6 rounded-xl">
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Mic className="w-5 h-5" />
                  Voice Control
                </h3>
                <button
                  onClick={handleVoiceCommand}
                  className={`w-full py-3 rounded-lg font-medium transition-colors ${
                    isListening
                      ? 'bg-red-600 hover:bg-red-700'
                      : 'bg-green-600 hover:bg-green-700'
                  }`}
                >
                  {isListening ? 'Stop Listening' : 'Start Listening'}
                </button>
                {isListening && (
                  <p className="mt-4 text-gray-300">Listening: {transcript}</p>
                )}
              </div>
            </div>

            <div className="bg-gray-800 p-6 rounded-xl">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Chat History
              </h3>
              <div className="space-y-4 h-[500px] overflow-y-auto">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`p-3 rounded-lg ${
                      message.sender === 'jarvis'
                        ? 'bg-blue-600 ml-4'
                        : 'bg-gray-700 mr-4'
                    }`}
                  >
                    <p className="text-sm font-medium mb-1">
                      {message.sender === 'jarvis' ? 'JARVIS' : 'You'}
                    </p>
                    <p className="text-gray-100">{message.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;